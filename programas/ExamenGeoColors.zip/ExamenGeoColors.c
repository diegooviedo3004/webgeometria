#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
//Creadores, DiegoMostacho, EliezerMostacho, K3vinMostacho 
int main(){
    int x,i;
	float num_final, area, volumen;
    char n[50],repetir;
    clrscr();
    
    do{
        textbackground(0);
        textcolor(WHITE);
        fflush( stdin );
                clrscr();
                //Validacion de espacios
                printf("\n\t\t    *******************");
                printf("\n\t\t    *Proyecto Geometria*");
                printf("\n\t\t    *******************");
                printf("\n\tPrograma de Superficie y Volumen de un Cubo");
                printf("\n\nIngrese Arista: ");
                scanf("%[^\n]%*c", n);
                printf("\nCheckeando input...\n");
                for(i=0;i<strlen(n);i++){
                    printf("%c\n",n[i]);
                    sleep(1);
                    if(n[i] == ' '){
                        printf("es un espacio\n");
                        sleep(1);
                        clrscr();
                        printf("Ingrese un input sin espacios");sleep(2);
                        return main();
                                   }
                }
        //Validacion de carateres     
                printf("Input correcto sin espacios");
                sleep(2);
                clrscr();
                printf("\nCheckeando validez de valores...\n");
                for(i=0;i<strlen(n);i++){
                    printf("%c\n",n[i]);
            	    if(n[i] != 48 && n[i] != 49 && n[i] != 50 && n[i] != 51 && n[i] != 52 && n[i] != 53 && n[i] != 54 && n[i] != 55 && n[i] != 55 && n[i] != 56 && n[i] != 57 && n[i] != 58){
            			printf("\nError introduzca un numero positivo y distinto que 0!!");
            			sleep(2);
            			return main();
            				}
            		if(strlen(n) == 1 && n[0] == 48){
            		    printf("\nError introduzca un numero positivo y distinto que 0!!");
            		    sleep(2);
            		    return main();
            		}
            
                }
         //En este punto los numeros son correctos       
                num_final = atof(n);
                area = pow(num_final,2)*6;
            	volumen = pow(num_final,3);

                textbackground(BLUE);
                textcolor(WHITE);
                clrscr();
            	printf("\n\tEl area de un cubo es: %.2f u2", area);
            	sleep(1);
            	printf("\n\tEl volumen de un cubo es: %.2f u3", volumen);
            	sleep(2);
            	
	// Despedida
	
                printf("\n\nSi desea continuar en el menu digite cualquier tecla distinta a n: ");
            	fflush(stdin);
            	scanf(" %c",&repetir);
                textbackground(RED);
            	
    }while(repetir!='n');
	clrscr();	
    	if(repetir='n') {
            printf("\n\t\t***********************");
    		printf("\n\t\t*Ha salido con exito!!*");
    	    printf("\n\t\t***********************");
        }
    
    getch();
    return 0;
}




